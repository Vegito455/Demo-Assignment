export class userDetails {
  firstName: string = "";
  lastName: string = "";
  email: string = "";
  mobile: number = null;
  age: number = null;
  state: string = "";
  country: string = "";
  address: string = "";
  address1: string = "";
  address2: string = "";
  companyAddress1: string = "";
  companyAddress2: string = "";
  subcribeNews: boolean;
  image: string = "";
}
